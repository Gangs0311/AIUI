﻿using CSV.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;

namespace CSV.APIController
{
    [Route( "api/[controller]" )]
    [ApiController]
    public class SearchController : ControllerBase
    {
        private readonly ILogger<SearchController> _logger;

        public SearchController(ILogger<SearchController> logger)
        {
            _logger = logger;
        }

        [HttpPost]
        [Route( "SearchExternalAPI" )]
        public IActionResult SearchExternalAPI(SearchExternalModel requestData)
        {
            try
            {
                string apiUrl;

                // Choose API URL based on the selected option
                if (requestData.databasetype == "ChromaDB")
                {
                    apiUrl = "http://172.206.11.134:5000/search";
                }
                else if (requestData.databasetype == "AI-Search")
                {
                    apiUrl = "http://172.206.11.134:8000/search";
                }
                else
                {
                    return BadRequest( "Invalid selected option" );
                }

                SearchApiRequestModel apiRequestModel = new SearchApiRequestModel();
                apiRequestModel.client_name = requestData.client_name;
                apiRequestModel.vendor_name = requestData.vendor_name;
                apiRequestModel.query = requestData.query;
                apiRequestModel.type = requestData.type;


                // Serialize the request data
                string jsonRequest = JsonConvert.SerializeObject( apiRequestModel );
                var content = new StringContent( jsonRequest, Encoding.UTF8, "application/json" );

                using (HttpClient httpClient = new HttpClient())
                {
                    HttpResponseMessage response = httpClient.PostAsync( apiUrl, content ).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        string jsonResponse = response.Content.ReadAsStringAsync().Result;
                        QueryResult responseData = JsonConvert.DeserializeObject<QueryResult>( jsonResponse );

                        if (responseData != null)
                        {
                            var result = responseData.response;
                            var res = responseData.result;
                            var srcdoc = responseData.source_documents;

                            string extractedResult = ExtractAI_Response( res );
                            string allDocuments = ConcatenateSourceDocuments( srcdoc );

                            return Ok( new ChatbotResponse
                            {
                                ExtractedResponse = extractedResult,
                                ActualResponse = result,
                                SourceDocuments = allDocuments
                            } );
                        }
                        else
                        {
                            return StatusCode( 500, "Unexpected response format from the external API" );
                        }
                    }
                    else
                    {
                        return StatusCode( 500, $"API request failed with status code {response.StatusCode}" );
                    }
                }
            }
            catch (JsonReaderException ex)
            {
                return StatusCode( 500, $"Error parsing JSON response: {ex.Message}" );
            }
            catch (HttpRequestException ex)
            {
                return StatusCode( 500, $"Error sending HTTP request: {ex.Message}" );
            }
            catch (Exception ex)
            {
                return StatusCode( 500, $"Internal server error occurred: {ex.Message}" );
            }
        }


        static string ExtractAI_Response(string response)
        {
            response = Regex.Replace( response, @"[^a-zA-Z0-9\s]", "" );
            string responseconvert = response.ToLower();
            string firstThreeCharacters = responseconvert.Substring( 0, Math.Min( responseconvert.Length, 3 ) );

            if (firstThreeCharacters.Contains( "yes" ))
            {
                return "Yes";
            }
            else if (firstThreeCharacters.Contains( "no" ))
            {
                return "No";
            }
            else
            {
                return "Others";
            }
        }

        static string ConcatenateSourceDocuments(List<SourceDocument> sourceDocuments)
        {
            string json = JsonConvert.SerializeObject( sourceDocuments, Formatting.Indented );
            return json;
        }
    }
}
