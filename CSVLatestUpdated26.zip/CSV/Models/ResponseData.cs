﻿namespace CSV.Models
{
    
    public class QueryResult
    {
        public string response { get; set; }

        public string result { get; set; }

        public List<SourceDocument> source_documents { get; set; }
     




    }

    public class SourceDocument
    {
        public string page { get; set; }
        public string page_content { get; set; }
        public string source { get; set; }
    }

}
