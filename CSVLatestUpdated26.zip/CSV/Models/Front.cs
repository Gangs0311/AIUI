﻿namespace CSV.Models
{
    public class Front
    {
        public string Query { get; set; }
        public string ClientName { get; set; }
        public string VendorName { get; set; }
    }
}
