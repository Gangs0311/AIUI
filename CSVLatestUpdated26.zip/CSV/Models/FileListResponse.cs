﻿namespace CSV.Models
{
    public class FileListResponse
    {
        
            public List<string> Files { get; set; }
        

    }
}
