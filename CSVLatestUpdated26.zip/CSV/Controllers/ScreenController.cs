﻿using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;



namespace CSV.Controllers
{
    public class ScreenController : Controller
    {
        private readonly IWebHostEnvironment _hostingEnvironment;

        public ScreenController(IWebHostEnvironment hostingEnvironment)
        {
            _hostingEnvironment = hostingEnvironment;
        }
        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> YourAction(string clientName, string vendorName)
        {
            if (string.IsNullOrEmpty( clientName ) || string.IsNullOrEmpty( vendorName ))
            {
                return Json( new { error = "ClientName and VendorName cannot be empty" } );
            }

            using (var httpClient = new HttpClient())
            {
                try
                {
                    string apiUrl = $"http://172.206.11.134:8000/file_list?client_name={clientName}&vendor_name={vendorName}";
                    HttpResponseMessage response = await httpClient.GetAsync( apiUrl );

                    if (response.IsSuccessStatusCode)
                    {
                        string responseData = await response.Content.ReadAsStringAsync();
                        return Content( responseData, "application/json" );
                    }
                    else
                    {
                        return Json( new { error = "Failed to retrieve data from the external API" } );
                    }
                }
                catch (Exception ex)
                {
                    return Json( new { error = ex.Message } );
                }
            }
        }


        [HttpPost]
        public ActionResult AddFile(string directory, string fileName, string fileContent)
        {
            try
            {
                var filePath = Path.Combine( _hostingEnvironment.WebRootPath, directory, fileName );
                System.IO.File.WriteAllText( filePath, fileContent );
                return Content( "File added successfully" );
            }
            catch (Exception ex)
            {
                return Content( "Error adding file: " + ex.Message );
            }
        }

        [HttpDelete]
        public ActionResult DeleteFile(string clientName, string vendorName, string fileName)
        {
            try
            {
                string directoryPath = Path.Combine( "D:\\Bot\\AI-POC-VRA-Docs\\AI-POC-VRA-Docs", clientName, vendorName );
                string filePath = Path.Combine( directoryPath, fileName );

                if (System.IO.File.Exists( filePath ))
                {
                    System.IO.File.Delete( filePath );
                    return Json( new { success = true, message = "File deleted successfully." } );
                }
                else
                {
                    return Json( new { success = false, message = "File not found." } );
                }
            }
            catch (Exception ex)
            {
                return Json( new { success = false, message = "Error deleting file: " + ex.Message } );
            }
        }


        [HttpPost]
        public async Task<ActionResult> UploadFile(IFormFile file, string clientName, string vendorName)
        {
            try
            {
                if (file != null && file.Length > 0 && !string.IsNullOrEmpty( clientName ) && !string.IsNullOrEmpty( vendorName ))
                {

                    using (var client = new HttpClient())
                    {

                        client.BaseAddress = new Uri( "http://172.17.13.62:8000/" );


                        using (var formData = new MultipartFormDataContent())
                        {

                            formData.Add( new StreamContent( file.OpenReadStream() ), "file", file.FileName );


                            formData.Add( new StringContent( clientName ), "clientName" );
                            formData.Add( new StringContent( vendorName ), "vendorName" );


                            var response = await client.PostAsync( "upload", formData );


                            if (response.IsSuccessStatusCode)
                            {
                                return Json( new { success = true, message = "File uploaded successfully." } );
                            }
                            else
                            {
                                return Json( new { success = false, message = "Failed to upload file. Status code: " + response.StatusCode } );
                            }
                        }
                    }
                }
                else
                {
                    return Json( new { success = false, message = "No file uploaded or client/vendor name is missing." } );
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine( "Error uploading file: " + ex.ToString() );
                return Json( new { success = false, message = "Error uploading file: " + ex.Message } );
            }
        }

        [HttpPost]
        public ActionResult AddClient(string newClientName)
        {
            try
            {
                string directoryPath = @"D:\Bot\AI-POC-VRA-Docs\AI-POC-VRA-Docs";


                string clientFolderPath = Path.Combine( directoryPath, newClientName );


                if (!Directory.Exists( clientFolderPath ))
                {

                    Directory.CreateDirectory( clientFolderPath );
                    ViewBag.Message = "Client added successfully.";
                }
                else
                {
                    ViewBag.Message = "Client already exists.";
                }
            }
            catch (Exception ex)
            {

                ViewBag.Message = "Error: " + ex.Message;
            }


            return RedirectToAction( "Index" );
        }

    }
}
