using CSV.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CSV.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpGet]
       

        [HttpGet]
        public IActionResult Upload()
        {
            return View();
        }

        [HttpGet]

        public IActionResult Screen() 
        {
            return View();
        }

        //[HttpPost]
        //public IActionResult Upload(FileDemo model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        if (model.File != null && model.File.Length > 0)
        //        {

        //            string uploadPath = Path.Combine("C:\\uploads", model.File.FileName);

        //            using (var fileStream = new FileStream(uploadPath, FileMode.Create))
        //            {
        //                model.File.CopyTo(fileStream);
        //            }

        //            ViewBag.Message = "File uploaded successfully.";
        //        }
        //    }

        //    return View(model);
        //}
    }
}
